	<div class="header">
        	<img src="imgs/Banner.png" style="width:50%; height:200px"/>
			  <!-- Thẻ Chứa Slideshow -->
  
        </div>