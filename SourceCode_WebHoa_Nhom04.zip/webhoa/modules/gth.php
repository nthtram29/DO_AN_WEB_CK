      
  <div class="gioiThieu">
  <div class="gioiThieu-1" style="font-size:35px;">
    🍂 Về Willowlea Florals 🍂
  </div>
<div class="gioiThieu-2">
        <div class="gioiThieu-2-1">
            <!-- <img scr="https://thuvienvector.com/upload/images/items/hinh-anh-hoa-la-mau-nuoc-file-png-3724.webp" style=" width:30%"> -->
            ✿︁ 🌺 Sứ mệnh của chúng tôi là giúp bạn trao đi tâm tư 
            và biến mọi dịp trọng đại của bạn trở nên đặc biệt hơn ✿︁


        </div>
        <div class="gioiThieu-2-2" >
            <!-- <img scr="https://i.pinimg.com/236x/57/72/4a/57724aa105a99a3a5643c4e79bf71bca.jpg" style=" width:30%"> -->
    
        <img src="https://cdn.pixabay.com/photo/2019/12/24/09/20/flowers-4716343_1280.png"style=" width:100%" >
        <!-- style="width: 200px;padding-top: 100px;" -->
        </div>
        <div class="gioiThieu-2-3">
            ✿︁ 🌷 Thông qua nền tảng trực tuyến, 
            chúng tôi mong muốn đem đến cho bạn trải nghiệm thật tiện lợi, 
            dễ dàng và tràn đầy niềm vui ✿︁
        </div>  
</div>      
<div class="gioiThieu-3" >
<!-- style="font-size:25px ;" -->
    ✿︁ 🌻 Đội ngũ giàu kinh nghiệm của chúng tôi luôn đảm bảo đem đến cho bạn những bó hoa tươi nhất 
    được gói cùng các loại nguyên vật liệu chất lượng cao. 
    Chúng tôi cung cấp nhiều chủng loại hoa, kích thước 
    và thiết kế khác nhau phù hợp cho bất kỳ dịp nào bạn cần ✿︁

    
</div>
  </div>