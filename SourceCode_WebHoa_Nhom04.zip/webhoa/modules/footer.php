<div class="footer">
	<h3 style="text-align:center ; line-height:70px; color:#000; font-size:20px;">© Willowlea Florals</h3>
	
</div>

